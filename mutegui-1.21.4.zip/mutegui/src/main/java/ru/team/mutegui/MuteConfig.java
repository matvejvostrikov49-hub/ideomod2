package ru.team.mutegui;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** Настройки лежат в config/mutegui.json и создаются при первом запуске. */
public class MuteConfig {
    // Команда мута. Подставляются {player}, {time}, {reason}. Подгони под свой плагин!
    public String muteCommand = "mute {player} {time} {reason}";
    // Команда, которая отправляется при клике на кнопку (без "/")
    public String openCommand = "work";
    // Как искать ник в сообщении. Группа 1 = ник. Подгони под формат чата сервера.
    public String nickRegex = "^(?:\\[[^\\]]*\\]\\s*|<)*([A-Za-z0-9_]{3,16})\\s*[:»>]";

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static MuteConfig load() {
        Path path = FabricLoader.getInstance().getConfigDir().resolve("mutegui.json");
        try {
            if (Files.exists(path)) {
                MuteConfig c = GSON.fromJson(Files.readString(path), MuteConfig.class);
                if (c != null) return c;
            }
            MuteConfig c = new MuteConfig();
            Files.writeString(path, GSON.toJson(c));
            return c;
        } catch (Exception e) {
            e.printStackTrace();
            return new MuteConfig();
        }
    }
}
