package ru.team.mutegui;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.*;
import net.minecraft.util.Formatting;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MuteModClient implements ClientModInitializer {
    public static MuteConfig CONFIG;

    @Override
    public void onInitializeClient() {
        CONFIG = MuteConfig.load();
        Pattern nickPattern = Pattern.compile(CONFIG.nickRegex);

        // Внутренняя клиентская команда, которую вызывает красная кнопка
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("mutegui_open")
                        .then(ClientCommandManager.argument("player", StringArgumentType.word())
                                .executes(ctx -> {
                                    String player = StringArgumentType.getString(ctx, "player");
                                    MinecraftClient mc = MinecraftClient.getInstance();
                                    mc.execute(() -> {
                                        if (mc.player == null) return;
                                        mc.player.networkHandler.sendChatCommand(CONFIG.openCommand);
                                        mc.setScreen(new MuteScreen(player));
                                    });
                                    return 1;
                                }))));

        // Добавляем красную кнопку в начало каждого сообщения игрока
        ClientReceiveMessageEvents.MODIFY_GAME.register((message, overlay) -> {
            if (overlay) return message;
            Matcher m = nickPattern.matcher(message.getString());
            if (!m.find()) return message;
            String player = m.group(1);

            MutableText button = Text.literal("[✖] ").setStyle(Style.EMPTY
                    .withColor(Formatting.RED)
                    .withBold(true)
                    .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/mutegui_open " + player))
                    .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT,
                            Text.literal("Замутить " + player).formatted(Formatting.RED))));

            return Text.empty().append(button).append(message);
        });
    }
}
